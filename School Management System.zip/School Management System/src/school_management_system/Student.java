package school_management_system;

/**
 * @author NivethaSrinivasan on 15/10/2022 
 * This class is responsible for keeping the 
 * records of Students name,grade,id,
 * fees paid & feesTotal
 * Fees for every student is rupees 35000
 * Students should pay the fees initially is rupees 12500
*/

public class Student {
	
	private int ID;
	private String NAME;
	private int GRADE;
	private static int feesPaid;
	private int feesTotal;
	
/**
 * Student is the Constructor which is used for initialising.
 * @param ID Id number is the unique for all students.
 * @param NAME Name is used to identify the students.
 * @param GRADE Grade is used to which grade is they are credited in the exams or others .
 */
	
public Student(int ID,String NAME,int GRADE) {
	this.feesPaid=0;
	this.feesTotal=35000;
	this.ID=ID;
	this.NAME=NAME;
	this.GRADE=GRADE;
}

/**
 * To update the grade is used
 * @param GRADE grade new grade of the student
 */

public void setgrade(int GRADE) {
	this.GRADE=GRADE;
}

/**
 * Add the fees to the fees paid
 * The school is going receive the funds
 * @param Fees the students which is pay for the school
 */

public static void payfees(int Fees) {
	feesPaid+=Fees;
	School.updateTotal_money_earned(feesPaid);
}

/**
 * 
 * @return ID of the student
 */

public int getID() {
	return ID;
}

/**
 * 
 * @return name of the student
 */

public String getName() {
	return NAME;
}

/**
 * 
 * @return GRADES of the students
 */

public int getGrade() {
	return GRADE;
}

/**
 * 
 * @return fees Paid by the student for the school
 */

public int getFeesPaid() {
	return feesPaid;
}

/**
 * 
 * @return total fees to the student
 */

public int getFeesTotal() {
	return feesTotal;
}

/**
 * 
 * @return the remaining fees students to pay for the school.
 */

public int getremainingFees() {
	return feesTotal-feesPaid;
}

/**
 * Return the details of the students.
 */

public String toString() {
	return "Student's name: "+NAME+" Total Fees Paid So far rupees "+feesPaid ;
	
}
}
