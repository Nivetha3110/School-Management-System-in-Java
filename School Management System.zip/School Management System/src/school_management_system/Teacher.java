package school_management_system;

/**
 * @author NivethaSrinivasan on 
 *This class is reponsible for keeping
 *the records of Teacher's name,ID,Salary
 */

public class Teacher {
	
	private int ID;
	private String NAME;
	private int SALARY;
	private int SalaryEarned;
	
/**
 * Creating a new Teacher object.
 * @param ID id for the teacher which is unique for everyone
 * @param NAME name of the teacher
 * @param SALARY salary of the teacher 
 */
	
public Teacher(int ID,String NAME,int SALARY) {
	this.ID=ID;
	this.NAME=NAME;
	this.SALARY=SALARY;
	this.SalaryEarned=0;
}

/**
 * 
 * @param ID id for the teacher
 * @return ID 
 */

public int getID(int ID) {
	return ID;
}

/**
 * 
 * @return NAME
 */

public String getName() {
	return NAME;
}

/**
 * 
 * @return SALARY salary which is earned by the teacher
 * by the school.
 */

public int getSalary() {
	return SALARY;
}

/**
 * 
 * @param SALARY
 * @return Salary
 */


public int setSalary(int SALARY) {
		this.SALARY=SALARY;
	return SALARY;
}


public void receiveSalary(int SALARY) {
	SalaryEarned+=SALARY;
	School.updateTotal_money_earned(SALARY);

}

/**
 * Returns the details of the teacher.
 */

public String toString() {
	return "Name of the Teacher: "+NAME+" Total Salary earned so far RUPEES "+SalaryEarned;
	
}

}
