package school_management_system;

/**
 * @author NivethaSrinivasan created on 16/10/2022.
 * 
 */


import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		//Declaring and Invoking a Teachers details with new keyword
		Teacher SriVidhya = new Teacher(101,"SRIVIDHYA",20000);
		Teacher Sivagami = new Teacher(107,"SIVAGAMI",17000);
		Teacher Dhaya = new Teacher(150,"DHAYA",70000);
		Teacher Srinivasan = new Teacher(103,"SRINIVASAN",25000);
	
		/**
		 * List of Teachers added by the School.
		 */
		
		List<Teacher> teacherList = new ArrayList<>();
		teacherList.add(Dhaya);
		teacherList.add(SriVidhya);
		teacherList.add(Sivagami);
		teacherList.add(Srinivasan);
		
		//Declaring and Invoking a Student details with new keyword
		Student Nivetha = new Student(29,"NIVETHA",5);
		Student Kalaivanan = new Student(12,"KALAIVANAN",1);
		Student Diya = new Student(4,"DIYA",2);
		
		/**
		 * List of Students added by the School.
		 */
		List<Student> StudentList = new ArrayList<>();
		StudentList.add(Kalaivanan);
		StudentList.add(Diya);
		StudentList.add(Nivetha);
		
		
		School APMHSS = new School(teacherList,StudentList);
		
		/**
		 * It is used to how much students pay the 
		 * fees for the school and how much total
		 * money earned by the school .
		 */
		
		Student.payfees(25000);
		Student.payfees(30000);
		Student.payfees(35000);
		System.out.println("APMHSS has Earned:"+APMHSS.getTotal_money_earned());
		
		/**
		 * The School total money spent for the Salary 
		 * for the particular Teachers.
		 */
		
		System.out.println("_____________ABC SCHOOL PAY SALARY________________________");
		SriVidhya.receiveSalary(SriVidhya.getSalary());
		System.out.println(" APMHSS has spent "+SriVidhya.getName()+" and now has RUPEES "+APMHSS.getTotal_money_earned());
		Sivagami.receiveSalary(Sivagami.getSalary());
		System.out.println(" APMHSS has spent "+Sivagami.getName()+" and now has RUPEES "+APMHSS.getTotal_money_earned());
		Dhaya.receiveSalary(Dhaya.getSalary());
		System.out.println("APMHSS has spent "+Dhaya.getName()+" and now has RUPEES "+APMHSS.getTotal_money_earned());
		
		/**
		 * It is used to print the students fees 
		 * so far for the school.
		*/
		
		System.out.println(Nivetha);
		System.out.println(Kalaivanan);
		System.out.println(Diya);
		
		/**
		 *How much salary get the Teachers by the School
		*/
		
		SriVidhya.receiveSalary(SriVidhya.getSalary());
		System.out.println(SriVidhya);
		Sivagami.receiveSalary(Sivagami.getSalary());
		System.out.println(Sivagami);
		Srinivasan.receiveSalary(Srinivasan.getSalary());
		Dhaya.receiveSalary(Dhaya.getSalary());
		System.out.println(Dhaya);
	
	}

}
