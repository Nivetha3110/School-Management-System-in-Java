package school_management_system;

/** 
 * @author NivethaSrinivasan created on 15/10/2022.
 * This class is responsible for representing many teachers and many students.
 * Implements Teachers and Students in ArrayList.
 */

import java.util.List;

public class School {
	
	private List<Teacher> teachers;
	private List<Student> students;
	private static int Total_money_earned ;
	private static int Total_money_spent;
	
/** 
 * new school object is created
 * @param teachers list of teachers in the school.
 * @param students list of students in the school.
 */

	public School(List<Teacher> teachers,List<Student> students) {
		this.teachers=teachers;
		this.students=students;
		Total_money_earned=0;
		Total_money_spent=0;
	}
	
/**
* 
* @return the list of teachers in the school
*/
	
	public List<Teacher> getTeachers() {
		return teachers;
	}
	
/**
* Added a teacher to the school who is working.
* @param teacher adding a teacher.
*/
	
	public void addTeachers(Teacher teacher) {
		this.addTeachers(teacher);
	}

/**
 * 
 * @return the list of students in the school
 */

	public List<Student> getStudents() {
		return students;
	}
	
/**
* Added a Students to the school.
* @param student add the students.
*/
	
	public void addStudents(Student student) {
		this.addStudents(student);
	}
	
/**
* Adds the total money earned by the school.
* @return the total money earned by the school. 
*/


	public int getTotal_money_earned() {
		return Total_money_earned;
	}
	
/**
 * Add the total money earned by the school.
 * @param money_earned money is supposed to be added.
 */

	public static void updateTotal_money_earned(int money_earned) {
		Total_money_earned += money_earned;
	}
	
	/**
	 * 
	 * @return the total money spent by the school.
	 * 
	 */

	public int getTotal_money_spent() {
		return Total_money_spent;
	}

/**
 * Update the total money spent by the school which 
 * is the salary the school is given to the students.
 * the total money spent = total money spent - money spent by the school.
 * @param money_spent the money spent by the school.
 */

	public static void updatemoney_spent(int money_spent) {
		Total_money_spent -= money_spent;
	}


}
